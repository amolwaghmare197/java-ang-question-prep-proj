package com.example.crud_oct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOctApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOctApplication.class, args);
	}

}
